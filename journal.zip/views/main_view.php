<div class="jumbotron bg-dark">
  <h1 class="display-4 text-light">Добро пожаловать на наш первый сайт!</h1>
  <p class="lead text-light">Узнайте последние новости из медиа!</p>
  <hr class="my-4">
  <p class='text-light'>Читайте, комментируйте, делитесь!</p>
  <a class="btn btn-primary btn-lg" href="/journal/News" role="button">Узнать новости</a>
</div>